import java.util.Scanner;
import java.util.HashMap;
import java.util.Map;

class Main {
    private static final Map<Character, Integer> ROMAN_MAP = new HashMap<>();
    static {
        ROMAN_MAP.put('I', 1);
        ROMAN_MAP.put('V', 5);
        ROMAN_MAP.put('X', 10);
        ROMAN_MAP.put('L', 50);
        ROMAN_MAP.put('C', 100);
        ROMAN_MAP.put('D', 500);
        ROMAN_MAP.put('M', 1000);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print("Введите выражение (например, 2 + 2): ");
            String input = scanner.nextLine();
            if (input.equals("exit")) {
                break;
            }
            try {
                String result = calc(input);
                System.out.println("Результат: " + result);
            } catch (Exception e) {
                System.out.println("Ошибка: " + e.getMessage());
                break;
            }
        }
        scanner.close();
    }

    static String calc(String input) {
        String[] parts = input.split(" ");
        String num1Str = parts[0];
        String operator = parts[1];
        String num2Str = parts[2];
        int num1, num2;

        try {
            num1 = isRoman(num1Str) ? romanToArabic(num1Str) : Integer.parseInt(num1Str);
            num2 = isRoman(num2Str) ? romanToArabic(num2Str) : Integer.parseInt(num2Str);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Введены некорректные числа!");
        }

        if ((isRoman(num1Str) && !isRoman(num2Str)) || (!isRoman(num1Str) && isRoman(num2Str))) {
            throw new IllegalArgumentException("Числа должны быть одного типа!");
        }

        if (num1 < 1 || num1 > 10 || num2 < 1 || num2 > 10) {
            throw new IllegalArgumentException("Числа должны быть от 1 до 10 включительно!");
        }

        int result = 0;

        switch (operator) {
            case "+":
                result = num1 + num2;
                break;
            case "-":
                result = num1 - num2;
                break;
            case "*":
                result = num1 * num2;
                break;
            case "/":
                if (num2 != 0 && num1 % num2 == 0) {
                    result = num1 / num2;
                } else {
                    throw new ArithmeticException("Деление должно быть целочисленным и без остатка!");
                }
                break;
            default:
                throw new IllegalArgumentException("Некорректный оператор!");
        }

        return isRoman(num1Str) ? arabicToRoman(result) : Integer.toString(result);
    }

    static boolean isRoman(String str) {
        for (char c : str.toCharArray()) {
            if (!ROMAN_MAP.containsKey(c)) {
                return false;
            }
        }
        return true;
    }

    static int romanToArabic(String roman) {
        int result = 0;
        int prevValue = 0;

        for (int i = roman.length() - 1; i >= 0; i--) {
            int value = ROMAN_MAP.get(roman.charAt(i));
            if (value < prevValue) {
                result -= value;
            } else {
                result += value;
            }
            prevValue = value;
        }

        return result;
    }

    static String arabicToRoman(int number) {
        if (number < 1) {
            throw new IllegalArgumentException("Число должно быть положительным!");
        }

        StringBuilder roman = new StringBuilder();

        for (Map.Entry<Character, Integer> entry : ROMAN_MAP.entrySet()) {
            char romanChar = entry.getKey();
            int value = entry.getValue();
            while (number >= value) {
                roman.append(romanChar);
                number -= value;
            }
        }

        return roman.toString();
    }
}
